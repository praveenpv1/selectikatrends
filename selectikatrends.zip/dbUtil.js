const MongoClient = require( 'mongodb' ).MongoClient;
// const url = "mongodb://localhost:27017";
const databasename = "feed_database";
const connUrl = 'mongodb+srv://trends:jXy45wo0259D@trends.i33nk.mongodb.net/' + databasename;


  var _db;

  const mongoclient = new MongoClient(connUrl, {
    connectTimeoutMS: 30000,
  });



module.exports = {

  connectToDatabase: function( callback) {
    mongoclient.connect().then((database) => {
      _db = database
      // console.log(database)
      return callback(database);
    }).catch(err => {
      console.log(err)
    });
  },

  getDb: function() {
    return _db;
  }
};